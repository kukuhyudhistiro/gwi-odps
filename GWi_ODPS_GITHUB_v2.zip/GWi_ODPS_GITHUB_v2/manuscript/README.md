# Manuscript

Paper artifacts: section drafts, tables, and figures.

> **Note**: These are k=7 era drafts. See [`PAPER_REVISION_k5_FINAL.md`](PAPER_REVISION_k5_FINAL.md) for k=5 revisions to apply.

---

## Contents

### Sections (`sections/`)

Markdown source of paper sections:

- `00_abstract.md` — Abstract (needs k=5 update per revision doc)
- `01_introduction.md` — Section 1: Introduction
- `02_related_work.md` — Section 2: Related Work
- `03_method.md` — Section 3: The GWi Pipeline + ODPS
- `04_experimental_setup.md` — Section 4: Experimental Setup
- `05_results.md` — Section 5: Experiments and Results
- `06_conclusions.md` — Section 6: Conclusions
- `99_references.md` — References (35 entries)

### Tables (`tables/`)

- `tables.md` — All tables in Markdown + LaTeX format

### Figures (`figures/`)

Pre-generated figures (placeholders/k=7). See `figures/README.md` for regeneration commands.

---

## Revisions

`PAPER_REVISION_k5_FINAL.md` contains comprehensive drop-in revisions for the k=5 baseline change:

- Abstract: reframe from "1.48× faster than GWC" → "2.2× faster (GWi) + parity (GWi+ODPS) + higher accuracy"
- Section 3.2: 4 ablation tables (BSDS500, BIPED, UDED, ranking)
- Section 3.6, 3.7: runtime statement updates
- Section 5.1-5.4: per-dataset narrative + table updates
- Section 5.5: ODPS ablation updates
- Section 6: conclusions update
- All key numbers refreshed
