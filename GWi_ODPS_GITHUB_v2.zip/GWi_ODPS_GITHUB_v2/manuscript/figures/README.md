# Manuscript Figures

Pre-generated figures used in the paper. Regenerate locally from your own data.

---

## Figures Included (Placeholders for k=7 — Regenerate for k=5)

| File | Status | Source script |
|------|--------|---------------|
| `figure_1_pipeline.png` | placeholder, regenerate | `scripts/generate_figure_1_pipeline.py` |
| `figure_2_sidelobe.png` | needs k=5 update | `scripts/generate_figure_2_3.py` |
| `figure_3_odps_schematic.png` | k-independent, keep | `scripts/generate_figure_2_3.py` |

---

## Figures to Generate After Pipeline Run

| File | Source script | Sample IDs |
|------|---------------|-----------|
| `figure_4_qualitative_BSDS500.png` | `06c_generate_final_figures.py` | 3063, 29030, 36046, 48017 |
| `figure_5_pr_curve_BSDS500.png` | `06c_generate_final_figures.py` | (uses eval CSV) |
| `figure_6_qualitative_BIPED.png` | `06c_generate_final_figures.py` | RGB_042, RGB_070, RGB_138 |
| `figure_7_pr_curve_BIPED.png` | `06c_generate_final_figures.py` | (uses eval CSV) |
| `figure_8_qualitative_UDED.png` | `06c_generate_final_figures.py` | 05-WIREFRAME-2, 04-0896x4, 28-img_043_SRF_2_HR |
| `figure_9_pr_curve_UDED.png` | `06c_generate_final_figures.py` | (uses eval CSV) |

---

## Generation Workflow

After running the pipeline (Section 2 of `docs/reproduction.md`):

```bash
# Figures 1-3 (single command each)
python scripts/generate_figure_1_pipeline.py \
    --output manuscript/figures/figure_1_pipeline.png \
    --stage-image-1 output/BSDS500/GWi/3063.png \
    --stage-image-5 output/BSDS500/GWi/3063.png \
    --stage-image-6 output/BSDS500/GWi_odps/3063.png

python scripts/generate_figure_2_3.py
mv figure_2_sidelobe.png figure_3_odps_schematic.png manuscript/figures/

# Figures 4-9 (single command for all)
python scripts/06c_generate_final_figures.py \
    --data-root ./data \
    --output-root ./output \
    --pr-curve-dir ./eval_results/k5 \
    --ods-summary ./eval_results/k5/ods_summary.csv \
    --figures-dir ./manuscript/figures
```

---

## Notes for k=5 Update

When updating `generate_figure_2_3.py` for k=5:

```python
# In make_placeholder_kernels() and Figure 2 panel (b):
# Old (k=7):
kx = np.arange(-3, 4)   # 7-tap kernel

# New (k=5):
kx = np.arange(-2, 3)   # 5-tap kernel
```

Figure 3 (ODPS schematic) is k-independent; no changes needed (d=2 holds for λ=4).
