# Abstract — GWi+ODPS for JESA Paper

> Target: ≤300 words, Purpose-Methodology-Findings-Implications structure.
> No AI buzzwords (rigorous, comprehensive, robust as praise, etc.).

---

## Abstract (Single Paragraph, 280 words)

The complex Gabor wavelet pairs a cosine (real) and sine (imaginary)
component to detect oriented image structure. For edge-based boundary
detection, where the target is the antisymmetric step transition between
regions, the contribution of the real component is not self-evident.
This work proposes GWi, an imaginary-only Gabor wavelet edge detector
that omits the real-component filter bank and replaces the Pythagorean
magnitude with absolute value, halving the convolution count of the
complex formulation. A characteristic of the absolute-value response is
the appearance of side-lobes at approximately ±λ/2 pixels from the true
edge, arising from the odd-symmetric sine modulation. We address this
artifact with ODPS (Orientation-aware Double-Peak Suppression), a Stage 6
post-processing module that reuses the orientation argmax from cross-
orientation max-pooling and compares each pixel against its two
neighbors along the edge-normal direction. ODPS requires no additional
convolutions. Evaluation on three human-annotated benchmarks under the
BSDS500 per-annotator matching protocol — BSDS500 (200 images), BIPED v2
(50 images at 1280×720), and UDED (30 cross-domain images), totaling 280
test images — shows that GWi exceeds complex Gabor in ODS on every
dataset by +0.012 to +0.079, supporting the redundancy of the real
component. ODPS adds approximately 6 milliseconds per image on BSDS500-
sized inputs and consistently improves ODS by +9-11%, yielding GWi+ODPS
values of 0.4481 (BSDS500), 0.5221 (BIPED), and 0.6277 (UDED). On the
cross-domain UDED benchmark, GWi+ODPS ranks second among seven classical
methods evaluated. The complete pipeline runs 1.28-1.48 times faster
than complex Gabor and 10.68-13.85 times faster than Phase Congruency
in single-threaded CPU measurements, making it the fastest multi-
orientation classical edge detector in the evaluated set.

## Keywords (alphabetical, ≤6)

Edge detection · Gabor wavelet · Imaginary component · Non-maximum
suppression · Orientation estimation · Phase Congruency

---

## Word Count Verification

```
Methods/Background:  ~80 words
Methodology:        ~110 words
Findings:           ~70 words
Implications:        ~20 words
Total:              ~280 words
```

Fits comfortably in the 250-300 word abstract limit typical of JESA.
