# Section 1 — Introduction

> ~1.5 pages

---

## 1. Introduction

Edge detection serves as a building block for many image analysis tasks,
including segmentation [1], object detection [2], and texture
classification [3]. Classical edge detectors such as Canny [4],
Sobel [5], and the Laplacian-of-Gaussian (LoG) [6] derive boundaries
from local image gradients and remain widely used in scenarios where
deep learning inference is impractical—on embedded devices, in
real-time pipelines, and in domains where labeled training data is
scarce. The Gabor wavelet, introduced by Daugman [7] as a
two-dimensional extension of Gabor's original communication theory
work, offers a different approach by combining a Gaussian envelope
with sinusoidal modulation. This construction extracts both edge
magnitude and orientation in a single operation, properties that
align with the response patterns of orientation-selective neurons
in the primary visual cortex [8].

The conventional formulation of the Gabor wavelet—henceforth Complex
Gabor (GWC)—uses two kernels per orientation: a cosine (real) part
sensitive to symmetric features such as ridges, and a sine (imaginary)
part sensitive to antisymmetric features such as step edges. Magnitude
is computed as the square root of the sum of squared real and imaginary
responses. This formulation has driven decades of edge detection
research [9, 10] but carries a cost: at *N* orientations, GWC requires
2*N* convolutions per image, plus a per-pixel square-root operation.
With the typical choice *N* = 8, GWC performs 16 convolutions per image.

A natural question follows: does the real component contribute new
boundary information beyond what the imaginary component already
encodes? For edge-based boundary detection on natural images, the
answer appears to be no. The imaginary (sine) kernel is the
antisymmetric detector that responds maximally to luminance step edges,
the structures of interest in human-annotated boundary datasets. The
real (cosine) kernel responds maximally to symmetric features such as
ridges and bars, which constitute a smaller fraction of human-annotated
edges on benchmarks such as BSDS500 [11] and BIPED [12].

This paper proposes an imaginary-only Gabor formulation (GWi) that
halves the convolution count of GWC and replaces the square-root
magnitude with an absolute-value operation. We also introduce a
post-processing stage we term Orientation-aware Double-Peak
Suppression (ODPS) that addresses a side-lobe artifact intrinsic to
the imaginary response: at parameter settings typical of edge detection
(kernel size 7, wavelength λ = 4), the absolute value of the sine
response produces two peaks at ±λ/2 ≈ ±2 pixels around the true edge
location, inflating false-positive predictions during evaluation. ODPS
reuses the argmax orientation map already computed during max-pooling,
requiring no additional convolution.

We evaluate the complete pipeline (Stages 1–6) against six classical
baselines on three human-annotated benchmarks—BSDS500, BIPED v2, and
UDED [13]—under the Berkeley evaluation protocol with multi-annotator
matching. The contributions of this work are:

1. We show empirically that the imaginary Gabor component alone matches
   or exceeds the boundary localization quality of complex Gabor across
   three datasets, while requiring half the convolution count. The
   improvement of GWi over GWC ranges from +0.012 ODS on BSDS500 to
   +0.079 ODS on BIPED.

2. We introduce ODPS as a Stage 6 post-processing operation that
   suppresses the side-lobe artifact predicted by the imaginary kernel
   structure. ODPS reuses the orientation argmax map from Stage 5 with
   no additional convolution. Adding ODPS lifts the pipeline's ODS by
   +0.043 on BSDS500, +0.044 on BIPED, and +0.061 on UDED.

3. We provide runtime measurements under single-threaded execution on
   a commodity CPU (Intel i5-14400). The complete GWi+ODPS pipeline
   runs in 29.1 ms on BSDS500 images (321 × 481), making it the fastest
   multi-orientation classical edge detector evaluated: 1.48× faster
   than GWC and 13.85× faster than Phase Congruency [14].

The remainder of this paper is structured as follows. Section 2
reviews classical and learning-based edge detection methods and the
use of Gabor wavelets in vision tasks. Section 3 describes the
proposed pipeline, including parameter selection and the ODPS step.
Section 4 details the evaluation protocol and datasets. Section 5
reports quantitative and qualitative results across the three
benchmarks, with separate subsections for each dataset and an ablation
of the ODPS stage. Section 6 discusses limitations and concludes.
