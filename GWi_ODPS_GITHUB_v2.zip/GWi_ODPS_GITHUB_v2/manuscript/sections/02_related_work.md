# Section 2 — Related Work

> ~1.5 pages
> Structure: 2.1 Classical, 2.2 Deep Learning, 2.3 Gabor in vision

---

## 2. Related Work

### 2.1 Classical Edge Detection

Roberts [15] introduced the first computational edge detector in 1963
using 2×2 difference operators. Sobel [5] and Prewitt [16] followed
with 3×3 separable operators that compute horizontal and vertical
gradient components. The Marr-Hildreth Laplacian-of-Gaussian (LoG) [6]
applies a Gaussian blur before second-order differentiation, providing
scale control through the Gaussian standard deviation. Canny [4]
introduced the multi-stage pipeline that remains the most widely used
classical detector: Gaussian smoothing, gradient computation, non-maximum
suppression (NMS) along the gradient direction, and hysteresis
thresholding using two threshold levels. The Canny algorithm operates
on a single orientation per pixel and produces thinned, connected edge
maps suitable for direct downstream use.

Phase Congruency (PC), proposed by Kovesi [14] and extended in
subsequent work [17], detects edges at locations where image Fourier
components are maximally in phase. PC is computed using multi-scale
log-Gabor filters in the frequency domain, providing illumination
invariance and detecting features beyond simple step edges (e.g., line
endings, corners). Edge Drawing (ED) [18] takes a different approach by
locating anchor points at gradient maxima and tracing connected edge
segments using a graph-walking procedure, yielding clean one-pixel-wide
edge chains.

These six methods—Roberts, Sobel, LoG, Canny, PC, and ED—form a
representative set of single-orientation gradient-based and
multi-orientation classical detectors. None requires training, and all
run on commodity CPUs in milliseconds. They serve as the comparison
baselines in this work.

### 2.2 Deep Learning Edge Detection

Holistically-Nested Edge Detection (HED) [19] adapted the VGG-16
classification network for pixel-wise edge prediction, demonstrating
that learned features could substantially exceed classical methods on
BSDS500 (ODS 0.788 versus 0.61 for Canny [11]). Subsequent work
focused on architecture refinement: Richer Convolutional Features (RCF)
[20] aggregated features from multiple convolutional layers; the
Bi-Directional Cascade Network (BDCN) [21] introduced scale enhancement
through dilated convolutions; Crisp Edge Detection (CED) [22] used a
refinement network to produce sharper boundaries.

Efforts to reduce model size while maintaining accuracy have produced
lightweight architectures. Pixel Difference Networks (PiDiNet) [23]
introduced pixel-difference convolutions that combine handcrafted
gradient operators with learned weights, achieving ODS 0.789 on BSDS500
with 0.69 M parameters. The Lightweight Dense CNN (LDC) [24] adapted the
DexiNed architecture [25] for efficient inference. The Traditional
Inspired Network (TIN) [26] used minimal feature extraction with
explicit feature fusion modules. The Learning Gabor Layer Network
(LGLNet) [27] integrated a learnable 150-parameter Gabor layer at the
input of a lightweight encoder-decoder, reaching ODS 0.805 on BSDS500
with 0.49 M total parameters.

Transformer-based detectors push the accuracy frontier further. EDTER
[28] applies a Vision Transformer backbone with a deep refinement
decoder, reaching ODS 0.848 on BSDS500. EdgeNAT [29] extends this
approach with neural architecture search and attains ODS 0.860. These
methods require GPU training, pre-trained backbones, and substantial
labeled data; they target accuracy rather than deployment efficiency.

The work reported here is positioned in a complementary direction. We
do not compete with deep learning detectors on absolute accuracy.
Instead, we ask which computational components of the classical Gabor
formulation contribute to boundary localization and which are
redundant. This question matters for two reasons: it informs the
design of hybrid Gabor-CNN architectures such as LGLNet, where Gabor
front-ends operate within deep networks; and it provides a CPU-
deployable alternative for resource-constrained settings.

### 2.3 Gabor Wavelets in Computer Vision

Daugman [7] introduced the two-dimensional Gabor function in 1980,
formulated as a Gaussian envelope modulated by a complex sinusoidal
plane wave. Jain et al. [3] demonstrated its effectiveness for texture
classification, exploiting its tunable frequency and orientation
selectivity. Grigorescu et al. [9] applied Gabor energy operators to
contour detection with nonclassical receptive field inhibition,
suppressing texture responses to highlight object boundaries.

Subsequent classical Gabor-based edge detectors include the
multi-bandwidth fusion approach of Lin et al. [10] and the scale-
multiplication method of Zhu et al. [30]. These methods all use the
complex Gabor formulation—both real and imaginary components combined
via magnitude. The work closest in spirit to ours is the odd-Gabor
transform-domain edge detection of Zhu et al. [30], which uses
imaginary-only filters but emphasizes adaptive thresholding rather
than computational efficiency.

In the deep learning era, Gabor functions have been integrated with
CNNs in several ways. Sarwar et al. [31] replaced the first two
convolutional layers of a CNN with fixed-parameter Gabor kernels to
reduce training cost. Luan et al. [32] modulated kernel weights with
Gabor functions to improve transformation invariance. Pérez et al. [33]
parameterized Gabor filters as learnable network components for
adversarial robustness. The recent LGLNet [27] computes orientation
angles dynamically from pixel-difference encoding, generating
spatially-varying Gabor filters at each location.

To our knowledge, no prior work has experimentally verified that the
imaginary component of the Gabor wavelet alone is sufficient for
edge-based boundary detection on human-annotated benchmarks under
strict per-annotator matching. The closest related claim comes from
the wavelet theory community, where the imaginary part of the analytic
Gabor signal is known to vanish at symmetric features and peak at
antisymmetric features [34]. Our work provides the empirical
counterpart: a quantitative demonstration on 280 test images from three
public benchmarks.
