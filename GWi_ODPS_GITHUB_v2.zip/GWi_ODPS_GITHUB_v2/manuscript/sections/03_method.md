# Section 3 — Proposed Method (FINAL with ODPS as Stage 6)

> Stage 6 is now a formal part of the pipeline. The "imaginary-only"
> claim refers to Stages 1-5; ODPS is a standard post-processing step
> analogous to NMS in Canny's pipeline.

---

## 3. The GWi Pipeline

The proposed pipeline consists of six stages: five core stages that
extract the imaginary Gabor response, plus a final orientation-aware
post-processing step that suppresses the side-lobe artifact inherent
to the `|sin|` response.

### 3.1 Stage 1: Preprocessing

Input RGB image *I*(x, y) is converted to grayscale via BT.601 weighting:

> *I*_gray(x, y) = 0.299·R + 0.587·G + 0.114·B

The grayscale image is histogram-equalized to maximize dynamic range,
then normalized to [0, 1]:

> *I*_norm(x, y) = HistEq(*I*_gray) / 255

### 3.2 Stage 2: Imaginary Gabor Kernel Construction

The 2D imaginary Gabor kernel at orientation θ is:

> *g*_θ(x, y) = exp(-(x'² + γ²y'²) / (2σ²)) · sin(2π x' / λ)

where (x', y') are the θ-rotated coordinates:
- x' = x·cos(θ) + y·sin(θ)
- y' = -x·sin(θ) + y·cos(θ)

We instantiate 8 kernels at θ ∈ {0°, 22.5°, 45°, ..., 157.5°} with
λ = 4, σ = 2.24, γ = 0.5, kernel size = 7×7.

### 3.3 Stage 3: Multi-orientation Convolution

Each kernel is convolved with the preprocessed image using zero-padded
2D convolution:

> *R*_θ(x, y) = *I*_norm ⊛ *g*_θ

### 3.4 Stage 4: Magnitude Extraction

The absolute value of each response replaces the typical
sqrt(real² + imag²) operation of complex Gabor:

> *M*_θ(x, y) = |*R*_θ(x, y)|

This is the central computational simplification of GWi — only the
imaginary kernel is convolved, and the absolute value yields the same
magnitude polarity as complex Gabor without the square-root operation.

### 3.5 Stage 5: Cross-orientation Max-Pooling

Per-pixel maximum across the 8 orientation responses, with argmax
preservation:

> *E*(x, y) = max_θ *M*_θ(x, y)
> 
> θ*(x, y) = argmax_θ *M*_θ(x, y)

The argmax map θ*(x, y) records which orientation contributed the
maximum response at each pixel and is consumed by Stage 6.

### 3.6 Stage 6: Orientation-aware Post-processing (ODPS)

The imaginary Gabor response exhibits side-lobes at ±λ/2 ≈ ±2 pixels
from the true edge, due to the odd-symmetric nature of `sin(·)` combined
with the absolute-value operation in Stage 4. To suppress these
side-lobes while preserving the imaginary-only character of Stages 1-5,
we apply orientation-aware non-maximum suppression that reuses the
argmax orientation map from Stage 5 without any additional convolution.

For each pixel (x, y), we compare its magnitude against two neighbors
along the edge-normal direction (the direction of θ*):

> *n*(x, y) = (cos θ*(x, y), sin θ*(x, y))

> *E*_ODPS(x, y) = *E*(x, y) if *E*(x, y) ≥ max(*E*(x + d·*n*), *E*(x − d·*n*))
> 
> *E*_ODPS(x, y) = 0          otherwise

with d = 2 pixels (corresponding to λ/2 for our parameter choice). The
vectorized implementation runs in approximately 6 ms on a 321×481 image.

ODPS adds approximately 47% to the GWi runtime (29.1 ms vs 19.7 ms on
BSDS500), but the absolute cost remains substantially lower than complex
Gabor (43.1 ms) and Phase Congruency (402.9 ms). The motivation for
positioning ODPS as a separate Stage 6 — rather than integrating it into
the kernel — is methodological clarity: Stages 1-5 alone constitute the
"imaginary-only" claim, while Stage 6 is a standard post-processing
operation found in many edge detection pipelines [Canny, 1986;
Kovesi, 1999].

### 3.7 Computational Cost Analysis

The complete GWi+ODPS pipeline performs:
- 8 convolutions of size 7×7 (Stages 3-4)
- 1 max-pool with argmax (Stage 5)
- 1 neighbor-comparison NMS (Stage 6)

Compared to complex Gabor (GWC):
- GWC requires 16 convolutions (8 real + 8 imaginary)
- GWC requires sqrt operation in magnitude
- GWC has no equivalent NMS step but still produces side-lobes from
  the cosine response

Thus, even with ODPS added, GWi+ODPS performs fewer convolutions than
GWC. The empirical speedup of 1.48× over GWC (Table [TX]) reflects the
combined savings.
