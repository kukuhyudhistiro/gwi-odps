# Section 4 — Experimental Setup

> ~0.5 page

---

## 4. Experimental Setup

### 4.1 Datasets

We evaluate on three publicly available human-annotated edge detection
benchmarks: BSDS500, BIPED v2, and UDED.

**BSDS500** [11] consists of 500 color images from natural scenes,
divided into 200 training, 100 validation, and 200 test images. Each
image is annotated independently by 5–6 human annotators, producing
ground truth boundary maps that capture inter-annotator variability.
We evaluate on the 200 test images at the original 321 × 481 resolution.

**BIPED v2** [12] contains 250 high-resolution color images (1280 × 720)
of urban scenes annotated by a single expert. The dataset is partitioned
into 200 training and 50 test images. The conservative single-annotator
protocol produces lower edge density (mean 3.26%) compared to BSDS500
(mean 6.63%). We use the 50 test images at original resolution.

**UDED** [13] is a curated cross-domain test set of 30 images drawn from
eight source datasets: BIPED, BSDS500, DIV2K, WIREFRAME, CITYSCAPES,
ADE20K, BSDS300, and CID. Image resolutions vary. Each image carries a
single annotator's ground truth. UDED is designed to assess
generalization across domains and provides edge density ranging from
1.60% to 19.87% (mean 6.37%, standard deviation 4.32%).

### 4.2 Evaluation Protocol

We follow the Berkeley evaluation protocol [11], which is the standard
for edge detection benchmarks. For each test image:

1. The prediction magnitude map is binarized at multiple threshold
   levels. We use 33 uniformly spaced thresholds in [1/34, 33/34],
   which provides sufficient precision-recall sampling at acceptable
   computational cost.
2. Each binary map is thinned to single-pixel-width edges using the
   morphological thinning algorithm of [35].
3. Predicted edge pixels are matched against ground truth edge pixels
   under a maximum distance tolerance of 0.0075 of the image diagonal.
   For 321 × 481 images this yields a tolerance of 4.34 pixels; for
   1280 × 720 BIPED images, 11.01 pixels.
4. For BSDS500 multi-annotator ground truth, prediction-side matching
   is performed independently against each annotator. A predicted
   pixel is counted as a true positive if it matches at least one
   annotator. Total ground-truth positives are summed across
   annotators.

From the per-threshold matching counts, we report three standard
metrics:

- **ODS** (Optimal Dataset Scale): single F-measure at the best fixed
  threshold across all images.
- **OIS** (Optimal Image Scale): mean F-measure with per-image optimal
  thresholds.
- **AP** (Average Precision): area under the precision-recall curve.

ODS and OIS are bounded in [0, 1]; higher values indicate better
boundary localization.

### 4.3 Baselines

We compare against six classical edge detectors: Canny [4], Sobel [5],
LoG [6], Phase Congruency [14], Edge Drawing [18], and Complex Gabor
(GWC). Canny is taken from OpenCV with default thresholds [50, 150].
Sobel uses a 3×3 separable kernel with magnitude
sqrt(*G*_x² + *G*_y²). LoG is implemented as a 7×7 kernel with σ = 1.4.
PC uses the original Kovesi implementation [14] with 4 scales and 6
orientations. ED uses the OpenCV ximgproc EdgeDrawing class with
default parameters. GWC uses the same kernel parameters as GWi
(*k* = 7, λ = 4, σ = 2.24, γ = 0.5, 8 orientations) with magnitude
sqrt(real² + imag²).

For deep learning comparison, we report published ODS values from PiDiNet
[23], LGLNet [27], EDTER [28], and EdgeNAT [29] on BSDS500. We do not
perform head-to-head experiments on matched hardware because the deep
methods require GPU inference; comparison is at the protocol level only.

### 4.4 Hardware and Software

All measurements are performed on an Intel Core i5-14400 CPU (10
performance + 4 efficiency cores, 16 hardware threads) with 16 GB
DDR4 memory under Windows 11. To eliminate threading-induced variance,
we set `cv2.setNumThreads(1)`, `OMP_NUM_THREADS=1`, and
`MKL_NUM_THREADS=1`. A warm-up pass of three images precedes timing to
discard cold-start effects.

Software stack: Python 3.13, NumPy 2.2.6, OpenCV 4.13.0 (with
ximgproc contrib for Edge Drawing), SciPy 1.5.3, scikit-image 0.21.

All evaluation code and edge map outputs are released to enable
reproduction. The complete pipeline runs end-to-end in approximately
5 minutes for all 280 test images across the three datasets.
