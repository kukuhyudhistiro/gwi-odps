# Section 6 — Conclusions

## 6. Conclusions and Future Work

This work investigated whether the real component of the complex Gabor
wavelet contributes information to edge-based boundary detection that
the imaginary component does not. We proposed GWi, an imaginary-only
Gabor wavelet edge detector that halves the convolution count of the
standard complex formulation, and ODPS, an orientation-aware post-
processing stage that suppresses the side-lobes inherent to the
absolute-value imaginary response by reusing the orientation argmax
from cross-orientation max-pooling.

Evaluation on three human-annotated benchmarks (BSDS500, BIPED v2,
and UDED), totaling 280 test images, supports two findings. First, the
imaginary component alone is sufficient: GWi exceeds complex Gabor in
ODS on every dataset by +0.012 to +0.079, indicating that the real
component does not contribute boundary information beyond what the
imaginary component already encodes. Second, the side-lobe artifact
of the absolute-value response can be removed at low computational
cost: ODPS adds approximately 6 milliseconds per image on BSDS500-sized
inputs and consistently improves ODS by +9-11% across the three
benchmarks. The combined pipeline, GWi+ODPS, achieves 0.4481 on BSDS500,
0.5221 on BIPED, and 0.6277 on UDED — on the cross-domain UDED, this
ranks second among the seven classical methods evaluated.

GWi+ODPS remains the fastest multi-orientation classical edge detector
in the evaluated set, running 1.28–1.48 times faster than complex Gabor
and 10.68–13.85 times faster than Phase Congruency. It is slower than
the single-gradient operators (Canny, Sobel, LoG, ED) by a factor of
5–18, which is the inherent cost of computing 8 oriented filter
responses per image.

### 6.1 Limitations

Three regimes where GWi+ODPS underperforms are identified in
Section 5.9. First, low-contrast textured regions produce responses
dominated by background variation, missing subtle edges that the
Gaussian-smoothed gradient operators capture. Second, edges thinner
than the 7-pixel kernel support are blurred by the band-pass envelope
of the Gabor filter. Third, very high edge density (>10%) causes
neighboring orientation responses to overlap, reducing the
discriminative power of per-orientation max-pooling.

The kernel parameters (size, wavelength, σ, γ, number of orientations)
are fixed globally in this work. Per-pixel adaptation to local image
statistics could plausibly address several of the limitations above,
particularly the third.

### 6.2 Future Work

We identify three directions for follow-up research.

First, **spatially adaptive Gabor filtering**, where kernel parameters
are conditioned on local image statistics rather than being fixed
globally. A density-aware variant could allocate finer angular sampling
in high-density regions and coarser sampling elsewhere, improving the
high-density regime without uniformly increasing the convolution count.

Second, **integration into hybrid Gabor-CNN architectures**. The
findings of this work are directly relevant to designs such as LGLNet
[Ding et al. 2025] that place a Gabor front-end before deep
convolutional layers. The convolution savings of GWi compound across
the depth of such networks, and ODPS can be inserted as a fixed
post-processing layer between Gabor and the trainable backbone.

Third, **quantization of the Gabor kernel for embedded deployment**.
The fixed-parameter, 8-bit-integer-friendly nature of GWi makes it a
candidate for INT8 inference on edge devices. Combined with ODPS as a
deterministic post-processing step, the pipeline maps directly to
mobile and embedded compute targets.

The present work provides a controlled baseline for these directions:
a classical, training-free, fixed-parameter Gabor edge detector with
quantified efficiency-quality trade-offs against six widely used
classical methods on three human-annotated benchmarks.
