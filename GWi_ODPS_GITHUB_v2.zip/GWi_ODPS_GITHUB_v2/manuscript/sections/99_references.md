# References

> 35 entries. All references are cited at least once in Sections 1–6.
> DOIs/URLs to be verified manually before submission — flag any
> entry marked [VERIFY] for portal lookup.

---

[1] Z. Hou, M. Qu, M. Cheng, S. Ma, Y. Wang, X. Yang, "EFRNet: Edge
feature refinement network for real-time semantic segmentation of
driving scenes," *Digital Signal Processing*, vol. 156, p. 104791, 2025.
DOI: 10.1016/j.dsp.2024.104791

[2] V. Ferrari, L. Fevrier, F. Jurie, C. Schmid, "Groups of adjacent
contour segments for object detection," *IEEE Transactions on Pattern
Analysis and Machine Intelligence*, vol. 30, no. 1, pp. 36–51, 2008.
DOI: 10.1109/TPAMI.2007.1144

[3] A. K. Jain, N. K. Ratha, S. Lakshmanan, "Object detection using
Gabor filters," *Pattern Recognition*, vol. 30, no. 2, pp. 295–309, 1997.
DOI: 10.1016/S0031-3203(96)00068-4

[4] J. Canny, "A computational approach to edge detection," *IEEE
Transactions on Pattern Analysis and Machine Intelligence*, vol.
PAMI-8, no. 6, pp. 679–698, 1986.
DOI: 10.1109/TPAMI.1986.4767851

[5] I. Sobel, G. Feldman, "A 3×3 isotropic gradient operator for image
processing," presented at the Stanford Artificial Intelligence Project
(SAIL), 1968. [Originally unpublished memo, widely reproduced in
Duda & Hart, *Pattern Classification and Scene Analysis*, Wiley, 1973.]

[6] D. Marr, E. Hildreth, "Theory of edge detection," *Proceedings of
the Royal Society of London. Series B, Biological Sciences*, vol. 207,
no. 1167, pp. 187–217, 1980.
DOI: 10.1098/rspb.1980.0020

[7] J. G. Daugman, "Two-dimensional spectral analysis of cortical
receptive field profiles," *Vision Research*, vol. 20, no. 10, pp.
847–856, 1980.
DOI: 10.1016/0042-6989(80)90065-6

[8] D. H. Hubel, T. N. Wiesel, "Receptive fields, binocular interaction
and functional architecture in the cat's visual cortex," *The Journal
of Physiology*, vol. 160, no. 1, pp. 106–154, 1962.
DOI: 10.1113/jphysiol.1962.sp006837

[9] C. Grigorescu, N. Petkov, M. A. Westenberg, "Contour detection based
on nonclassical receptive field inhibition," *IEEE Transactions on
Image Processing*, vol. 12, no. 7, pp. 729–739, 2003.
DOI: 10.1109/TIP.2003.814250

[10] C. Lin, F. Li, Y. Cao, H. Zhao, "Bio-inspired contour detection
model based on multi-bandwidth fusion and logarithmic texture
inhibition," *IET Image Processing*, vol. 13, no. 12, pp. 2304–2313,
2019. DOI: 10.1049/iet-ipr.2019.0419

[11] P. Arbelaez, M. Maire, C. Fowlkes, J. Malik, "Contour detection
and hierarchical image segmentation," *IEEE Transactions on Pattern
Analysis and Machine Intelligence*, vol. 33, no. 5, pp. 898–916, 2011.
DOI: 10.1109/TPAMI.2010.161

[12] X. Soria, E. Riba, A. Sappa, "Dense extreme inception network:
Towards a robust CNN model for edge detection," in *Proceedings of the
IEEE Winter Conference on Applications of Computer Vision (WACV)*, 2020,
pp. 1923–1932. DOI: 10.1109/WACV45572.2020.9093290

[13] X. Soria, Y. Li, M. Rouhani, A. D. Sappa, "Tiny and efficient
model for the edge detection generalization," in *Proceedings of the
IEEE/CVF International Conference on Computer Vision (ICCV) Workshops*,
2023, pp. 1364–1373.
[UDED dataset reference]

[14] P. Kovesi, "Image features from phase congruency," *Videre:
Journal of Computer Vision Research*, vol. 1, no. 3, pp. 1–26, 1999.
[Available at https://www.peterkovesi.com/papers/]

[15] L. G. Roberts, "Machine perception of three-dimensional solids,"
Ph.D. thesis, Massachusetts Institute of Technology, 1963.
[Available via MIT DSpace]

[16] J. M. S. Prewitt, "Object enhancement and extraction," in *Picture
Processing and Psychopictorics*, B. S. Lipkin and A. Rosenfeld, Eds.,
Academic Press, 1970, pp. 75–149.

[17] P. Kovesi, "Phase congruency: A low-level image invariant,"
*Psychological Research*, vol. 64, no. 2, pp. 136–148, 2000.
DOI: 10.1007/s004260000024

[18] C. Topal, C. Akinlar, "Edge Drawing: A combined real-time edge
and segment detector," *Journal of Visual Communication and Image
Representation*, vol. 23, no. 6, pp. 862–872, 2012.
DOI: 10.1016/j.jvcir.2012.05.004

[19] S. Xie, Z. Tu, "Holistically-nested edge detection," in
*Proceedings of the IEEE International Conference on Computer Vision
(ICCV)*, 2015, pp. 1395–1403.
DOI: 10.1109/ICCV.2015.164

[20] Y. Liu, M.-M. Cheng, X. Hu, K. Wang, X. Bai, "Richer convolutional
features for edge detection," in *Proceedings of the IEEE Conference
on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp.
3000–3009. DOI: 10.1109/CVPR.2017.622

[21] J. He, S. Zhang, M. Yang, Y. Shan, T. Huang, "Bi-directional
cascade network for perceptual edge detection," in *Proceedings of the
IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*,
2019, pp. 3828–3837. DOI: 10.1109/CVPR.2019.00395

[22] Y. Wang, X. Zhao, K. Huang, "Deep crisp boundaries," in
*Proceedings of the IEEE Conference on Computer Vision and Pattern
Recognition (CVPR)*, 2017, pp. 3892–3900. DOI: 10.1109/CVPR.2017.415

[23] Z. Su, W. Liu, Z. Yu, D. Hu, Q. Liao, Q. Tian, M. Pietikäinen,
L. Liu, "Pixel difference networks for efficient edge detection," in
*Proceedings of the IEEE/CVF International Conference on Computer
Vision (ICCV)*, 2021, pp. 5117–5127. DOI: 10.1109/ICCV48922.2021.00507

[24] X. Soria, G. Pomboza-Junez, A. D. Sappa, "LDC: Lightweight dense
CNN for edge detection," *IEEE Access*, vol. 10, pp. 68281–68290, 2022.
DOI: 10.1109/ACCESS.2022.3186344

[25] X. Soria, A. Sappa, P. Humanante, A. Akbarinia, "Dense extreme
inception network for edge detection," *Pattern Recognition*, vol. 139,
p. 109461, 2023. DOI: 10.1016/j.patcog.2023.109461

[26] J. K. Wibisono, H.-M. Hang, "Traditional method inspired deep
neural network for edge detection," in *Proceedings of the IEEE
International Conference on Image Processing (ICIP)*, 2020, pp.
678–682. DOI: 10.1109/ICIP40778.2020.9191038

[27] H. Ding, S. Huang, C. Lin, "Learning Gabor layer for edge
detection network," *Digital Signal Processing*, vol. 167, p. 105438,
2025. DOI: 10.1016/j.dsp.2025.105438

[28] M. Pu, Y. Huang, Y. Liu, Q. Guan, H. Ling, "EDTER: Edge detection
with transformer," in *Proceedings of the IEEE/CVF Conference on
Computer Vision and Pattern Recognition (CVPR)*, 2022, pp. 1402–1412.
DOI: 10.1109/CVPR52688.2022.00146

[29] J. Jie, S. Guo, G. Wu, J. Yang, "EdgeNAT: Transformer for
efficient edge detection," *arXiv preprint*, arXiv:2408.10527, 2024.
[VERIFY: check for published version in venue]

[30] Z. Zhu, H. Lu, Y. Zhao, "Scale multiplication in odd Gabor
transform domain for edge detection," *Journal of Visual Communication
and Image Representation*, vol. 18, no. 1, pp. 68–80, 2007.
DOI: 10.1016/j.jvcir.2006.11.001

[31] S. S. Sarwar, P. Panda, K. Roy, "Gabor filter assisted energy
efficient fast learning convolutional neural networks," in *Proceedings
of the IEEE/ACM International Symposium on Low Power Electronics and
Design (ISLPED)*, 2017, pp. 1–6. DOI: 10.1109/ISLPED.2017.8009202

[32] S. Luan, C. Chen, B. Zhang, J. Han, J. Liu, "Gabor convolutional
networks," *IEEE Transactions on Image Processing*, vol. 27, no. 9,
pp. 4357–4366, 2018. DOI: 10.1109/TIP.2018.2835143

[33] J. C. Pérez, M. Alfarra, G. Jeanneret, A. Bibi, A. Thabet, B.
Ghanem, P. Arbeláez, "Gabor layers enhance network robustness," in
*Computer Vision – ECCV 2020*, Lecture Notes in Computer Science, vol.
12354, Springer, 2020, pp. 450–466.
DOI: 10.1007/978-3-030-58545-7_26

[34] B. Boashash, "Estimating and interpreting the instantaneous
frequency of a signal—Part 1: Fundamentals," *Proceedings of the IEEE*,
vol. 80, no. 4, pp. 520–538, 1992.
DOI: 10.1109/5.135376

[35] T. Y. Zhang, C. Y. Suen, "A fast parallel algorithm for thinning
digital patterns," *Communications of the ACM*, vol. 27, no. 3, pp.
236–239, 1984.
DOI: 10.1145/357994.358023

---

## Verification Checklist (before submission)

- [ ] All 35 DOIs verified via Crossref or publisher portal
- [ ] [VERIFY] tags resolved (currently: ref [29] EdgeNAT)
- [ ] Cross-references in text match numbering (citation order, IJIES
  protocol may require resorting)
- [ ] Standardize author name format (initial vs full name) across
  all entries
- [ ] Check year format (2024 vs 2025 for in-press papers)
- [ ] Verify Soria et al. UDED reference [13] — exact venue and page
  numbers from ICCV Workshops proceedings
